const vars = {
  "SLACK_API_TOKEN": "exqoE99l8QOZ6T1wq6uEaprO"
}

module.exports = vars;